# IP2 合并交接说明（v2，2026-10-29 晚）

> 给 A：请用这一版 RTL 重跑合并。相比你上次合并用的版本，功能等价性不变（我们已用 128×72 与 640×360 的全链仿真逐字节对齐），
> 但**检测能力、寄存器映射、面积都变了**，直接沿用旧版会出现“只认 2~4 px”和“读候选表读不到”的问题。

## 1. 文件清单（`rtl/` 下 10 个 .v，全部替换）

| 文件 | 本次是否有改动 | 说明 |
|---|---|---|
| `ip2_axi_bd_wrap.v` | 改 | BD 包装层；`parameter W=640, H=360, MAX_CAND=64`，`S_AXI ADDR_WIDTH 6` |
| `ip2_axi_top.v` | **大改** | 寄存器/状态机/帧缓冲/候选表窗口；`parameter SE=21, MODE=0` |
| `ip2_axi_master_rd.v` | 未改 | AXI4 读主（32×8B 突发） |
| `ip2_axi_master_wr.v` | 未改 | AXI4 写主 |
| `ip2_top_stream.v` | 改 | 三级串联 + `SE/MODE` 参数下传 |
| `tophat_5x5_stream.v` | **大改** | 结构元参数化 + `MODE`（0=Top-Hat，1=Black-Hat） |
| `win5.v` | **重写** | 结构元参数化（SE 条行缓存 + SE×SE 抽头 + 平衡树归约） |
| `minmax_tree.v` | **新增** | 平衡树 min/max 归约（6 级），替代 441 级线性链，**时序全靠它** |
| `cfar_threshold_stream.v` | 改 | `K=1`（原 4）、`FLOOR=3`、31×31 双滑动盒 |
| `candidate_extract_stream.v` | **大改** | `MAX_CAND=64`、`MAX_AREA=2047`、area 扩到 16 位、输出 452 字节 |

## 2. 关键参数（改动前后对比）

| 参数 | 你上次合并的版本 | 本版 | 影响 |
|---|---|---|---|
| **结构元 SE** | 5×5 | **21×21** | 检出范围 2~4 px → **2~20 px** |
| `MAX_AREA` | 200 | **2047** | 不再把 15×15 以上的目标当噪声砍掉 |
| area 位宽 | 8 位（≤255） | **16 位** | 大目标面积不再溢出 |
| `MAX_CAND` | 5 | **64**（452 字节） | 密集场景不再只留前 5 个 |
| CFAR `K` | 4 | **1** | 缓解“大目标自抑制” |
| 候选表窗口地址 | `0x40/0x44`（8 位地址分支，已废弃） | **`0x10`**（6 位地址） | 见 §4，**必读** |

## 3. 资源与时序（我们自己的 BD，SE=21 版实测）

```
LUT      54,345 / 78,600   = 69.14%
LUTRAM   14,807 / 26,600   = 55.67%
BRAM     64 / 265          （帧缓冲 1 个 256KB LUTRAM/RAMB）
FF       17,703
时序     50 MHz：WNS +1.444 ns，TNS 0，WHS met（"All user specified timing constraints are met"）
帧耗时   8~10 ms（640×360，50 MHz）
```

⚠️ **合并预警**：SE=21 版单独就占 69% LUT + 56% LUTRAM。AI_Mate 本身约 18,166 LUT，
两者相加约 **92%**，再加互联/其它逻辑有超面积风险。如果装不下，按这个顺序降级：

1. **SE=15**（检出 ≤14 px，LUTRAM 约降 1/3）—— 推荐首选折中；
2. SE=11（检出 ≤10 px）；
3. 保住 SE=21 但把 `MAX_CAND` 从 64 降回 16（候选表 RAM 由 452 B → 116 B，省 LUTRAM）。

## 4. 寄存器映射（**权威，务必按这个对齐**；详见 `docs/23-寄存器映射与候选表窗口.md`）

6 位地址：

| 偏移 | 写 | 读 |
|---|---|---|
| `0x00` | start（自清零） | `{31'd0,start_r}` |
| `0x04` / `0x08` | frame_addr / result_addr | 同 |
| `0x0C` | — | STATUS：bit0 busy、bit1 done、bit2 err、[15:8] 约 n_cand、高 8 位帧计数 |
| **`0x10`** | **候选表窗口字索引（0~112）** | **该字的 32 位数据** |
| `0x14` | — | VERSION = `0x00010000` |
| `0x18`~`0x38` | — | 36 字节兼容视图（n + 前 5 个候选，S 的 web_console 用这个） |
| `0x3C` | — | `{done, err, 14'd0, frame_id}` |

**坑**：`0x40` 在 6 位地址下会绕回 `0x00`（= 误触发一帧），读 `0x44` 得到的是 `frame_addr`。
我们所有 PS 脚本之前都栽在这里，已全部改成 `0x10`。

**候选表格式**：byte0 = `min(n_comp, MAX_CAND)`；每候选 7 字节
`[x_hi, x_lo, y_hi, y_lo, area_hi, area_lo, peak]`，x/y/area 各 16 位（大端），peak 8 位。

## 5. IP 参数固化提醒（上次踩过）

Vivado 会把 `W/H/MAX_CAND/DEF_*_ADDR` 写进 `.xci` 的 `MODELPARAM_VALUE`，
**只改 RTL 默认值没用**，必须：

- 在 BD 里打开该 IP 的 “Re-customize” 改参数；或
- 直接编辑 `ip2_bd_ip2_0_0.xci` 里的 `MODELPARAM_VALUE.MAX_CAND` 为 `64`；或
- 删掉 IP 重新 `create_bd_cell`（我们批处理这条路会因模块解析失败，只能在 GUI 里做）。

改完记得 `reset_run` 该 IP 的 OOC 综合 + `update_compile_order -fileset sources_1`。

## 6. 请帮忙确认的三件事（NPU 卡死）

我们在你的合并位流上跑 `session.forward`：
`Device initialization successful` 之后进程不返回，**整板失联**（以太网链路 Up 1Gbps，但两个 IP 都不响应、ARP 学不到 MAC），只能断电。

1. `ip_patch` 那 21 个行为级空壳具体是哪些模块？有没有触及 **NPU 的 DMA / 中断**路径？
2. BD 里 **User Level Shifter 是否使能**？（青龙手册：PL 中断 16~19 上电默认浮空，必须先配 bit 再使能）
3. NPU 的中断号是否仍是 **16~19**？合并后有没有改？

## 7. 自查脚本（不依赖板子）

`tb/tb_se_sweep.v`：160×120、单目标尺寸扫描，编译后 `vvp xx.vvp +ts=12` 即可看到该尺寸是否被检出、area 是否等于 ts²。
用它可以 30 秒验证“换完 RTL 后 SE 是否真的生效”。

```bash
iverilog -g2005 -o se_sweep.vvp tb/tb_se_sweep.v rtl/minmax_tree.v rtl/win5.v \
         rtl/tophat_5x5_stream.v rtl/cfar_threshold_stream.v \
         rtl/candidate_extract_stream.v rtl/ip2_top_stream.v
vvp se_sweep.vvp +ts=12      # 期望：n_cand=1 area=144
vvp se_sweep.vvp +ts=22      # 期望：n_cand=0（超过 SE-1=20）
```
